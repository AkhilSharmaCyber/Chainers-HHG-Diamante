const DiamSdk = require("diamante-sdk-js");
const fetch = require('node-fetch');
const EventSource = require("eventsource");
const readline = require('readline');

const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

const server = new DiamSdk.Horizon.Server("https://diamtestnet.diamcircle.io/");


async function promptUser(query) {
    return new Promise((resolve) => {
        rl.question(query, (answer) => {
            resolve(answer);
        });
    });
}

async function createAccount() {
    try {
        const pair = DiamSdk.Keypair.random();
        console.log("New Public Key:", pair.publicKey());
        console.log("New Secret Key:", pair.secret());

        const friendbotURL = `https://friendbot.diamcircle.io?addr=${encodeURIComponent(pair.publicKey())}`;
        const response = await fetch(friendbotURL);
        if (!response.ok) throw new Error('Failed to fund account');
        const responseJSON = await response.json();
        console.log("Friendbot Response:", pair);

        return pair;
    } catch (error) {
        console.error("Error creating account:", error);
        return null;
    }
}

async function loginAccount() {
    try {
        const publicKey = await promptUser("Enter your public key: ");
        const secretKey = await promptUser("Enter your secret key: ");
        
        const pair = DiamSdk.Keypair.fromSecret(secretKey);

        const account = await server.loadAccount(publicKey);
        console.log("Account Loaded Successfully!");
        return { account, pair };
    } catch (error) {
        console.error("Error loading account:", error);
        return null;
    }
}

async function setupTrustline(parentAccount, pair) {
    try {
        const assetCode = await promptUser("Enter the asset code (e.g., USD): ");
        const issuerPublicKey = await promptUser("Enter the asset issuer public key: ");
        const asset = new DiamSdk.Asset(assetCode, issuerPublicKey);
        const trustTransaction = new DiamSdk.TransactionBuilder(parentAccount, {
            fee: DiamSdk.BASE_FEE,
            networkPassphrase: DiamSdk.Networks.TESTNET,
        })
            .addOperation(DiamSdk.Operation.changeTrust({
                asset: asset,
            }))
            .setTimeout(180)
            .build();

        trustTransaction.sign(pair);
        const trustResult = await server.submitTransaction(trustTransaction);
        console.log("Trustline Set Successfully!", trustResult);
    } catch (error) {
        console.error("Error setting up trustline:", error);
    }
}

async function issueAsset(parentAccount, pair) {
    try {
        const assetCode = await promptUser("Enter the asset code (e.g., USD): ");
        const issuerPublicKey = await promptUser("Enter the asset issuer public key: ");
        const amount = await promptUser("Enter the amount to issue: ");
        const asset = new DiamSdk.Asset(assetCode, issuerPublicKey);
        const issueTransaction = new DiamSdk.TransactionBuilder(parentAccount, {
            fee: DiamSdk.BASE_FEE,
            networkPassphrase: DiamSdk.Networks.TESTNET,
        })
            .addOperation(DiamSdk.Operation.payment({
                destination: pair.publicKey(),
                asset: asset,
                amount: amount,
            }))
            .setTimeout(180)
            .build();

        issueTransaction.sign(pair);
        const issueResult = await server.submitTransaction(issueTransaction);
        console.log("Asset Issued Successfully!", issueResult);
    } catch (error) {
        console.error("Error issuing asset:", error);
    }
}

async function makePayment(parentAccount, pair) {
    try {
        const amount = await promptUser("Enter the amount to pay: ");
        const paymentTransaction = new DiamSdk.TransactionBuilder(parentAccount, {
            fee: DiamSdk.BASE_FEE,
            networkPassphrase: DiamSdk.Networks.TESTNET,
        })
            .addOperation(DiamSdk.Operation.payment({
                destination: pair.publicKey(),
                asset: DiamSdk.Asset.native(),
                amount: amount,
            }))
            .setTimeout(30)
            .build();

        paymentTransaction.sign(pair);
        const paymentResult = await server.submitTransaction(paymentTransaction);
        console.log("Payment Successful!", paymentResult);
    } catch (error) {
        console.error("Error making payment:", error);
    }
}

async function manageBuyOffer(parentAccount, pair) {
    try {
        const sellingCode = await promptUser("Enter the asset code you are selling (e.g., XLM): ");
        const sellingIssuer = await promptUser("Enter the asset issuer public key for the selling asset: ");
        const buyingCode = await promptUser("Enter the asset code you are buying (e.g., USD): ");
        const buyingIssuer = await promptUser("Enter the asset issuer public key for the buying asset: ");
        const buyAmount = await promptUser("Enter the amount to buy: ");
        const price = await promptUser("Enter the price per unit: ");
        const offerId = await promptUser("Enter the offer ID (use 0 for a new offer): ");

        const sellingAsset = new DiamSdk.Asset(sellingCode, sellingIssuer);
        const buyingAsset = new DiamSdk.Asset(buyingCode, buyingIssuer);
        const buyOfferTransaction = new DiamSdk.TransactionBuilder(parentAccount, {
            fee: DiamSdk.BASE_FEE,
            networkPassphrase: DiamSdk.Networks.TESTNET,
        })
            .addOperation(DiamSdk.Operation.manageBuyOffer({
                selling: sellingAsset,
                buying: buyingAsset,
                buyAmount: buyAmount,
                price: price,
                offerId: parseInt(offerId),
            }))
            .setTimeout(180)
            .build();

        buyOfferTransaction.sign(pair);
        const buyOfferResult = await server.submitTransaction(buyOfferTransaction);
        console.log("Buy Offer Successful!", buyOfferResult);
    } catch (error) {
        console.error("Error managing buy offer:", error);
    }
}

async function manageSellOffer(parentAccount, pair) {
    try {
        const sellingCode = await promptUser("Enter the asset code you are selling (e.g., USD): ");
        const sellingIssuer = await promptUser("Enter the asset issuer public key for the selling asset: ");
        const buyingCode = await promptUser("Enter the asset code you are buying (e.g., XLM): ");
        const buyingIssuer = await promptUser("Enter the asset issuer public key for the buying asset: ");
        const amount = await promptUser("Enter the amount to sell: ");
        const price = await promptUser("Enter the price per unit: ");
        const offerId = await promptUser("Enter the offer ID (use 0 for a new offer): ");

        const sellingAsset = new DiamSdk.Asset(sellingCode, sellingIssuer);
        const buyingAsset = new DiamSdk.Asset(buyingCode, buyingIssuer);
        const sellOfferTransaction = new DiamSdk.TransactionBuilder(parentAccount, {
            fee: DiamSdk.BASE_FEE,
            networkPassphrase: DiamSdk.Networks.TESTNET,
        })
            .addOperation(DiamSdk.Operation.manageSellOffer({
                selling: sellingAsset,
                buying: buyingAsset,
                amount: amount,
                price: price,
                offerId: parseInt(offerId),
            }))
            .setTimeout(180)
            .build();

        sellOfferTransaction.sign(pair);
        const sellOfferResult = await server.submitTransaction(sellOfferTransaction);
        console.log("Sell Offer Successful!", sellOfferResult);
    } catch (error) {
        console.error("Error managing sell offer:", error);
    }
}

function streamPayments(pair) {
    try {
        const es = new EventSource(`https://diamtestnet.diamcircle.io/accounts/${pair.publicKey()}/payments`);
        es.onmessage = function (message) {
            const result = message.data ? JSON.parse(message.data) : message;
            console.log("New payment:");
            console.log(result);
        };
        es.onerror = function (error) {
            console.error("An error occurred while streaming payments:", error);
        };
    } catch (error) {
        console.error("Error setting up payment stream:", error);
    }
}

async function handlePreconditions(parentAccount, pair) {
    try {
        const minTime = await promptUser("Enter the minimum time (UNIX timestamp): ");
        const maxTime = await promptUser("Enter the maximum time (UNIX timestamp): ");
        const amount = await promptUser("Enter the amount to send: ");

        const preconditionTransaction = new DiamSdk.TransactionBuilder(parentAccount, {
            fee: DiamSdk.BASE_FEE,
            networkPassphrase: DiamSdk.Networks.TESTNET,
            timebounds: {
                minTime: parseInt(minTime),
                maxTime: parseInt(maxTime),
            }
        })
            .addOperation(DiamSdk.Operation.payment({
                destination: pair.publicKey(),
                asset: DiamSdk.Asset.native(),
                amount: amount,
            }))
            .setTimeout(180)
            .build();

        preconditionTransaction.sign(pair);
        const preconditionResult = await server.submitTransaction(preconditionTransaction);
        console.log("Precondition Transaction Successful!", preconditionResult);
    } catch (error) {
        console.error("Error handling preconditions:", error);
    }
}

async function pathfinding() {
    try {
        const destinationAmount = await promptUser("Enter the amount to find a path for: ");
        const paths = await server.paths()
            .sourceAccount(pair.publicKey())
            .destinationAccount(pair.publicKey())
            .destinationAsset(DiamSdk.Asset.native())
            .destinationAmount(destinationAmount)
            .call();
        console.log("Pathfinding Result:", paths);
    } catch (error) {
        console.error("Error performing pathfinding:", error);
    }
}

async function paymentChannel(parentAccount, pair) {
    try {
        const receiverPublicKey = await promptUser("Enter the recipient public key: ");
        const startingBalanceA = await promptUser("Enter the starting balance for client A: ");
        const startingBalanceB = await promptUser("Enter the starting balance for client B: ");
        const amountToSend = await promptUser("Enter the amount to send: ");

        const paymentChannel = new DiamSdk.Starlight.PaymentChannel({
            server: server,
            clientASecret: pair.secret(),
            clientBPublic: receiverPublicKey,
        });

        await paymentChannel.open({
            startingBalanceA: startingBalanceA,
            startingBalanceB: startingBalanceB,
        });

        await paymentChannel.send(amountToSend);
        await paymentChannel.close();

        console.log("Payment Channel Transaction Complete");
    } catch (error) {
        console.error("Error handling payment channel:", error);
    }
}

async function userPrompt() {
    let continueLoop = true;
    while (continueLoop) {
        const choice = await promptUser(`Select an operation to perform:
      1: Set up a trustline
      2: Issue an asset
      3: Make a payment
      4: Manage buy offer
      5: Manage sell offer
      6: Stream payments
      7: Handle preconditions
      8: Pathfinding
      9: Payment Channel
      0: Exit
      Enter your choice: `);

        switch (choice) {
            case '1':
                await setupTrustline(parentAccount, pair);
                break;
            case '2':
                await issueAsset(parentAccount, pair);
                break;
            case '3':
                await makePayment(parentAccount, pair);
                break;
            case '4':
                await manageBuyOffer(parentAccount, pair);
                break;
            case '5':
                await manageSellOffer(parentAccount, pair);
                break;
            case '6':
                streamPayments(pair);
                break;
            case '7':
                await handlePreconditions(parentAccount, pair);
                break;
            case '8':
                await pathfinding();
                break;
            case '9':
                await paymentChannel(parentAccount, pair);
                break;
            case '0':
                continueLoop = false;
                break;
            default:
                console.log("Invalid choice, please try again.");
        }
    }

    rl.close();
}

(async function main() {
    try {
        let pair, parentAccount;

        const action = await promptUser(`Select an action:
      1: Create a new account
      2: Login to an existing account
      Enter your choice: `);

        if (action === '1') {
            pair = await createAccount();
            if (pair) {
                parentAccount = await server.loadAccount(pair.publicKey());
            }
        } else if (action === '2') {
            const result = await loginAccount();
            if (result) {
                parentAccount = result.account;
                pair = result.pair;
            } else {
                console.error("Login failed.");
                rl.close();
                return;
            }
        } else {
            console.log("Invalid choice.");
            rl.close();
            return;
        }

        
        await userPrompt();

    } catch (error) {
        console.error("Error:", error);
    }
})();
